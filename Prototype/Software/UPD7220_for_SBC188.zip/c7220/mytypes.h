#ifndef __MYTYPES_H
#define __MYTYPES_H 1

typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned long dword;

#endif  /* __MYTYPES_H */
